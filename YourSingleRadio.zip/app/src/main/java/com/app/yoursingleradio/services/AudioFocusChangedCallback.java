package com.app.yoursingleradio.services;

public interface AudioFocusChangedCallback {

    void onFocusGained();

    void onFocusLost();
}
