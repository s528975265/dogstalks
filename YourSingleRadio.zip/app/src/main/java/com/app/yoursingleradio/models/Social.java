package com.app.yoursingleradio.models;

import java.io.Serializable;

public class Social implements Serializable {

    public String social_name = "";
    public String social_icon = "";
    public String social_url = "";

}
