package com.app.yoursingleradio.models;

import java.io.Serializable;

public class Settings implements Serializable {

    public String app_status = "";
    public String privacy_policy_url = "";
    public String more_apps_url = "";
    public String redirect_url = "";

}
