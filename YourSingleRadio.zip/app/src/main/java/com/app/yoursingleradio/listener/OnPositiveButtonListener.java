package com.app.yoursingleradio.listener;

public interface OnPositiveButtonListener {

    void onPositive();

}