package com.app.yoursingleradio.listener;

public interface OnCompleteListener {

    void onComplete();

}