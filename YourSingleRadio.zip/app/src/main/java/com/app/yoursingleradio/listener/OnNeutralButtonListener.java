package com.app.yoursingleradio.listener;

public interface OnNeutralButtonListener {

    void onNeutral();

}