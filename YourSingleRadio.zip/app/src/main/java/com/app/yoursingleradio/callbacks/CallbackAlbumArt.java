package com.app.yoursingleradio.callbacks;

import com.app.yoursingleradio.models.AlbumArt;

import java.util.ArrayList;

public class CallbackAlbumArt {

    public int resultCount = -1;
    public ArrayList<AlbumArt> results = new ArrayList<>();

}
